#ifdef __APPLE__

#endif

#ifdef __MINGW32__
#include <windows.h>

long int MilliSecs()
{
	return GetTickCount();
}

void Delay( int millis )
{
	Sleep(millis);
}

#endif

#ifdef __linux
#include <sys/time.h>

long int MilliSecs()
{
	int t;
	struct timeval tv;
	gettimeofday(&tv,0);
	t=tv.tv_sec*1000;
	t+=tv.tv_usec/1000;
	return t;
}

void Delay( int millis )
{
	int i,e;
	if( millis<0 ) return;

	e=MilliSecs()+millis;
	
	for( i=0;;++i ){
		int t=e-MilliSecs();
		if( t<=0 ){
			if( !i ) usleep( 0 );	//always sleep at least once.
			break;
		}
		usleep( t*1000 );
	}
}

#endif
