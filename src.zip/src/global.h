#pragma once

typedef std::string string;

Tpoint mouse_pos;
float win_to_map_x;
float win_to_map_y;
int window_width;
int window_height;

struct sSettings
{
	bool gm_fullscreen;
} settings;

void MouseMoveFunc(int x, int y);
