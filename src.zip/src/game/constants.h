#pragma once

#define oTypeTank 100
#define oTypeBullet 110
#define oTypeWater 10
