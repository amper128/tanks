#pragma once

class TSprite
{

}
